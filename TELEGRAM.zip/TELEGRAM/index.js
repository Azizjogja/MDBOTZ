"use strict";

/**
 * Telegram entry point (Node.js 18+)
 * - Telegraf (polling)
 * - Config from .env
 * - Adapter -> Handler
 *
 * Legacy WA entry should be renamed to: wa_index.js
 */

require("dotenv").config();

const { Telegraf } = require("telegraf");
const { adaptTelegramMessage } = require("./telegram/adapter");
const { createTelegramHandler } = require("./telegram/handler");

const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) {
  console.error("Missing TELEGRAM_BOT_TOKEN in .env");
  process.exit(1);
}

const bot = new Telegraf(token, { handlerTimeout: 60_000 });
const handler = createTelegramHandler({ bot });

// handle normal text messages
bot.on("text", async (ctx) => {
  const { m, meta } = adaptTelegramMessage(ctx);
  await handler.handleText(ctx, m, meta);
});

// handle caption-based messages (photo/document with caption)
bot.on(["photo", "document"], async (ctx) => {
  const { m, meta } = adaptTelegramMessage(ctx);
  await handler.handleText(ctx, m, meta);
});

// global error handling
bot.catch((err, ctx) => {
  console.error("Telegraf error:", err);
  try {
    if (ctx?.reply) ctx.reply("Terjadi error…");
  } catch {}
});

process.on("unhandledRejection", (err) => console.error("UnhandledRejection:", err));
process.on("uncaughtException", (err) => console.error("UncaughtException:", err));

bot
  .launch({ dropPendingUpdates: true })
  .then(() => console.log("✅ Telegram bot running (polling)."))
  .catch((e) => {
    console.error("Failed to launch bot:", e);
    process.exit(1);
  });

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));