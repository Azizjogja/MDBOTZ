#Script rizal-developer 
*Base By rizaldev*
*Pengembang Script rizaldev*

#Script ini gratis Dari rizaldev
#Dilarang Menjual Belikan

#Sumber
#https://chat.whatsapp.com/I0VOoR3wSqzB4v98TR6DtI?mode=hqrt3

#group#1 : https://chat.whatsapp.com/I0VOoR3wSqzB4v98TR6DtI

#group#2 : 
https://chat.whatsapp.com/Dn3OhGj0m7d3d29TmBUt24


*‣ wa* : wa.me/6283119115977
*‣ tele* : t.me/rizeldev
*‣ testi* : https://t.me/testirizel
*‣ Bot order* : t.me/rizaldevorder_bot

> rizaldev
