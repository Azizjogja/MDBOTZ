import { Telegraf } from 'telegraf';

/* =========================
   ISI TOKEN LANGSUNG DI SINI
   ========================= */
const TELEGRAM_BOT_TOKEN = "8513790057:AAFU3x_Xd4Nxslae6sDX1SKrJY9alDeKzGM";
const DEEPSEEK_API_KEY   = "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";

/* ========================= */

const DEEPSEEK_BASE_URL = "https://api.deepseek.com";
const MODEL = "deepseek-chat";

if (!TELEGRAM_BOT_TOKEN) throw new Error("Telegram token kosong");
if (!DEEPSEEK_API_KEY) throw new Error("DeepSeek API key kosong");

const bot = new Telegraf(TELEGRAM_BOT_TOKEN);

// simpan memory chat per user
const histories = new Map();
const MAX_HISTORY = 10;

function getHistory(id) {
  if (!histories.has(id)) histories.set(id, []);
  return histories.get(id);
}

async function deepseekChat(messages) {
  const res = await fetch(`${DEEPSEEK_BASE_URL}/chat/completions`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${DEEPSEEK_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      temperature: 0.7,
      max_tokens: 800
    })
  });

  if (!res.ok) {
    const t = await res.text();
    throw new Error(`DeepSeek error ${res.status}: ${t}`);
  }

  const data = await res.json();
  return data.choices[0].message.content;
}

bot.start(ctx => {
  ctx.reply(
    "Hai! Aku bot AI pakai DeepSeek.\n\n" +
    "Kirim pesan apa saja.\n" +
    "/reset - hapus konteks"
  );
});

bot.command("reset", ctx => {
  histories.set(ctx.from.id, []);
  ctx.reply("Konteks di-reset ✅");
});

bot.on("text", async ctx => {
  const userId = ctx.from.id;
  const text = ctx.message.text;

  const history = getHistory(userId);

  const messages = [
    { role: "system", content: "Jawab dalam Bahasa Indonesia, jelas dan singkat." },
    ...history,
    { role: "user", content: text }
  ];

  try {
    await ctx.sendChatAction("typing");
    const reply = await deepseekChat(messages);

    history.push({ role: "user", content: text });
    history.push({ role: "assistant", content: reply });

    if (history.length > MAX_HISTORY) {
      history.splice(0, history.length - MAX_HISTORY);
    }

    ctx.reply(reply);
  } catch (e) {
    ctx.reply("Error: " + e.message);
  }
});

bot.launch();
console.log("✅ Bot berjalan (polling)");